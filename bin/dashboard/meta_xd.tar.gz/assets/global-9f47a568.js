import{Y as a}from"./vendor-5507c805.js";import{ac as m}from"./index-bd53d7c8.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
